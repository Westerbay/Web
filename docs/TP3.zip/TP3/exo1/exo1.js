function a() {
    setTimeout(function () { alert("Réveillez-vous !") }, 4000);
}
